/** Automatically generated file. DO NOT MODIFY */
package com.skobbler.ngx;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}