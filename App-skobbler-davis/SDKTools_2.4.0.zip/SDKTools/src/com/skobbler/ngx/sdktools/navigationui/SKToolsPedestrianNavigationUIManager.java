package com.skobbler.ngx.sdktools.navigationui;

import android.app.Activity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Class that handles the pedestrian UI
 * Created by mirceab on 14.02.2015.
 */
public class SKToolsPedestrianNavigationUIManager {


    /**
     * Singleton instance for current class
     */
    private static SKToolsPedestrianNavigationUIManager instance = null;

    /**
     * the current activity
     */
    private Activity currentActivity;
    /**
     * root layout - to this will be added all views
     */
    private ViewGroup rootLayout;
    /**
     * the settings from navigations
     */
    private ViewGroup settingsPanel;

    /*
    the view for pre navigation
     */
    private ViewGroup preNavigationPanel;

    /*
    the view for pre navigation increase decrease buttons
     */
    private ViewGroup navigationSimulationPanel;

    /**
     * the back button
     */
    private ViewGroup backButtonPanel;
    /**
     * compass panel
     */
    protected ViewGroup compassPanel;
    /**
     * pedestrian follower mode toast
     */
    private static Toast pedestrianFollowerModeToast;


    /**
     * Creates a single instance of {@link SKToolsPedestrianNavigationUIManager}
     *
     * @return
     */
    public static SKToolsPedestrianNavigationUIManager getInstance() {
        if (instance == null) {
            synchronized (SKToolsNavigationUIManager.class) {
                if (instance == null) {
                    instance = new SKToolsPedestrianNavigationUIManager();
                }
            }
        }
        return instance;
    }

    /**
     * Sets the current activity.
     *
     * @param activity
     * @param rootId
     */
    protected void setActivity(Activity activity, int rootId) {
        this.currentActivity = activity;
        rootLayout = (ViewGroup) currentActivity.findViewById(rootId);
    }


}


